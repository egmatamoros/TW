import React from 'react';
import ReactDOM from 'react-dom';


import './styles/styles.scss'
import {Proyecto} from "./Proyecto";


ReactDOM.render(
    <Proyecto />,
  document.getElementById('root')
);