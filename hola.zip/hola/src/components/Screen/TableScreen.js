import React from 'react';

export const TableScreen = () =>{
    return(
        <>
            <h1>Table Screen</h1>
        </>
    )
}


